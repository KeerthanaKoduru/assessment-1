# Resume Analyzer

A full-stack Resume Analyzer built with Node.js, Express, PostgreSQL, and PDF parsing.

## Setup Instructions

1. Clone or unzip this project.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Update PostgreSQL connection in `app.js`:
   ```js
   const pool = new Pool({
     user: "postgres",
     host: "localhost",
     database: "resume_analyzer",
     password: "password", // change to your password
     port: 5432,
   });
   ```

4. Start the server:
   ```bash
   npm start
   ```

5. Open [http://localhost:5000](http://localhost:5000) in your browser.

## Features
- Upload resume PDF.
- Extract text from resume.
- Mock AI analysis (replace with real Google Gemini API).
- Store structured analysis in PostgreSQL.
- View analysis history.

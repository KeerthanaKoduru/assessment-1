
// app.js
// Run: npm install express multer pdf-parse pg cors
// Start: node app.js

const express = require("express");
const multer = require("multer");
const pdfParse = require("pdf-parse");
const { Pool } = require("pg");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

// PostgreSQL setup
const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "resume_analyzer",
  password: "password", // change to your password
  port: 5432,
});

// Create table if not exists
(async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS resumes (
      id SERIAL PRIMARY KEY,
      name TEXT,
      email TEXT,
      phone TEXT,
      linkedin TEXT,
      raw_text TEXT,
      analysis JSONB,
      filename TEXT,
      uploaded_at TIMESTAMP DEFAULT NOW()
    )
  `);
})();

// Multer setup for file upload
const upload = multer({ dest: "uploads/" });

// Mock Gemini AI (replace with real API later)
function mockGeminiAnalysis(text) {
  return {
    personalDetails: {
      name: "John Doe",
      email: "johndoe@email.com",
      phone: "+1234567890",
      linkedin: "https://linkedin.com/in/johndoe",
    },
    resumeContent: {
      summary: "Experienced software engineer with expertise in full-stack development.",
      workExperience: ["Company A - Developer", "Company B - Intern"],
      education: ["B.Tech in CSE - XYZ University"],
      projects: ["Resume Analyzer App"],
      certifications: ["AWS Certified Developer"],
    },
    skills: {
      technical: ["JavaScript", "React", "Node.js", "PostgreSQL"],
      soft: ["Communication", "Problem Solving"],
    },
    feedback: {
      rating: 8,
      improvements: ["Add more measurable achievements", "Highlight leadership roles"],
      suggestedSkills: ["Docker", "Kubernetes", "Cloud Security"],
    },
  };
}

// API: Upload resume & analyze
app.post("/api/upload", upload.single("resume"), async (req, res) => {
  try {
    const pdfBuffer = req.file ? require("fs").readFileSync(req.file.path) : null;
    const data = await pdfParse(pdfBuffer);
    const rawText = data.text;

    // Call Gemini AI (mocked here)
    const analysis = mockGeminiAnalysis(rawText);

    // Insert into DB
    const result = await pool.query(
      `INSERT INTO resumes (name, email, phone, linkedin, raw_text, analysis, filename) 
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [
        analysis.personalDetails.name,
        analysis.personalDetails.email,
        analysis.personalDetails.phone,
        analysis.personalDetails.linkedin,
        rawText,
        analysis,
        req.file.originalname,
      ]
    );

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: "Resume analysis failed" });
  }
});

// API: Fetch history
app.get("/api/history", async (req, res) => {
  const result = await pool.query("SELECT * FROM resumes ORDER BY uploaded_at DESC");
  res.json(result.rows);
});

// Serve simple frontend
app.get("/", (req, res) => {
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <title>Resume Analyzer</title>
</head>
<body>
  <h1>Upload Resume</h1>
  <form id="uploadForm">
    <input type="file" name="resume" />
    <button type="submit">Upload</button>
  </form>
  <h2>Analysis Result</h2>
  <pre id="result"></pre>
  <h2>History</h2>
  <button onclick="loadHistory()">Load History</button>
  <pre id="history"></pre>
  <script>
    document.getElementById("uploadForm").onsubmit = async (e) => {
      e.preventDefault();
      let formData = new FormData(e.target);
      let res = await fetch("/api/upload", { method: "POST", body: formData });
      let data = await res.json();
      document.getElementById("result").innerText = JSON.stringify(data, null, 2);
    };
    async function loadHistory() {
      let res = await fetch("/api/history");
      let data = await res.json();
      document.getElementById("history").innerText = JSON.stringify(data, null, 2);
    }
  </script>
</body>
</html>
  `);
});

app.listen(5000, () => console.log("Server running on http://localhost:5000"));
